<?php
namespace PortForward;

use \PortForward\Base as Base;

class BandwidthLimter
{
    public $b;
    public function __construct()
    {
        $this->b = new Base();
    }

    public function rule_create($data)
    {
        if(filter_var(trim($data['forwardip']), FILTER_VALIDATE_IP,FILTER_FLAG_IPV6)){
            // v6
            foreach($data['nic'] as $nic){
                $this->b->run('tc qdisc add dev '.$nic.' root handle 1: htb');
                $this->b->run('tc class add dev '.$nic.' parent 1: classid 1:'.$data['serviceid'].' htb rate '.$data['bandwidth'].'Mbps ceil '.$data['bandwidth'].'Mbps prio 1');
                $this->b->run('tc filter add dev '.$nic.' protocol ipv6 parent 1:0 prio 2 handle '.$data['serviceid'].'0'.' fw flowid 1:'.$data['serviceid']);
                $this->b->run('tc filter add dev '.$nic.' protocol ip parent 1:0 prio 1 handle '.$data['serviceid'].'1'.' fw flowid 1:'.$data['serviceid']);
                $this->b->run('ip6tables -t mangle -A POSTROUTING -p tcp -d '.$data['forwardip'].' --dport '.$data['forwardport'].' -j MARK --set-mark '.$data['serviceid'].'0');
                $this->b->run('iptables -A OUTPUT -t mangle -p tcp --sport '.$data['nodeport'].' -j MARK --set-mark '.$data['serviceid'].'1');
            }
        }else{
            // v4
            foreach($data['nic'] as $nic){
                $this->b->run('tc qdisc add dev '.$nic.' root handle 1: htb');
                $this->b->run('tc class add dev '.$nic.' parent 1: classid 1:'.$data['serviceid'].' htb rate '.$data['bandwidth'].'Mbps ceil '.$data['bandwidth'].'Mbps prio 1');
                $this->b->run('tc filter add dev '.$nic.' protocol ip parent 1:0 prio 1 handle '.$data['serviceid'].'0'.' fw flowid 1:'.$data['serviceid']);
                $this->b->run('iptables -t mangle -A POSTROUTING -p tcp -d '.$data['forwardip'].' --dport '.$data['forwardport'].' -j MARK --set-mark '.$data['serviceid'].'0');
                $this->b->run('iptables -A OUTPUT -t mangle -p tcp --sport '.$data['nodeport'].' -j MARK --set-mark '.$data['serviceid'].'0');
            }
         }
        return true;
    }

    public function rule_delete($data)
    {
        if (filter_var(trim($data['forwardip']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            // v6
            foreach ($data['nic'] as $nic) {
                $this->b->run('ip6tables -t mangle -D POSTROUTING -p tcp -d ' . $data['forwardip'] . ' --dport ' . $data['forwardport'] . ' -j MARK --set-mark ' . $data['serviceid'] . '0');
                $this->b->run('iptables -D OUTPUT -t mangle -p tcp --sport ' . $data['nodeport'] . ' -j MARK --set-mark ' . $data['serviceid'] . '1');
                $this->b->run('tc filter del dev ' . $nic . ' protocol ipv6 parent 1:0 prio 2 handle ' . $data['serviceid'] . '0' . ' fw flowid 1:' . $data['serviceid']);
                $this->b->run('tc filter del dev ' . $nic . ' protocol ip parent 1:0 prio 1 handle ' . $data['serviceid'] . '1' . ' fw flowid 1:' . $data['serviceid']);
                $this->b->run('tc class del dev ' . $nic . ' parent 1: classid 1:' . $data['serviceid'] . ' htb rate ' . $data['bandwidth'] . 'Mbps ceil ' . $data['bandwidth'] . 'Mbps prio 1');
            }
        } else {
            // v4
            foreach ($data['nic'] as $nic) {
                $this->b->run('iptables -t mangle -D POSTROUTING -p tcp -d ' . $data['forwardip'] . ' --dport ' . $data['forwardport'] . ' -j MARK --set-mark ' . $data['serviceid'] . '0');
                $this->b->run('iptables -D OUTPUT -t mangle -p tcp --sport ' . $data['nodeport'] . ' -j MARK --set-mark '.$data['serviceid'] . '0' );
                $this->b->run('tc filter del dev ' . $nic . ' protocol ip parent 1:0 prio 1 handle ' . $data['serviceid'] . '0' . ' fw flowid 1:' . $data['serviceid']);
                $this->b->run('tc class del dev ' . $nic . ' parent 1: classid 1:' . $data['serviceid'] . ' htb rate ' . $data['bandwidth'] . 'Mbps ceil ' . $data['bandwidth'] . 'Mbps prio 1');            }
        }
    }
}