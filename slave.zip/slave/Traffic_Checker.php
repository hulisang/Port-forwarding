<?php
namespace PortForward;

require __DIR__ . "/init.php";
require __DIR__ . "/config.php";

use \PortForward\TrafficCounter as TrafficCounter;
use \PortForward\Base as Base;
echo " PortForward Node v1.21 By Jiuling";
if (!empty($isGetConfig)) {
	if($isGetConfig) {
		$base = new Base();
		echo "\n Get config from master...\n\n";
		$data = [
    			'key' => $key,
			'token' => $token,
    			'action' => 'getconfig',
   			'0ba7yh8J' => 'aloIJ952xJ',
		];
		$result = json_decode($base->Post($url,$data),true);
		if ($result['status'] == 'success') {
			$magnification = $result['config']['magnification'];
			$node_bw_max = $result['config']['node_bw_max'];
		} else {
		echo "\n Failed to get config from master! \n";
		}
	}
}
echo "\n Collecting data...";

$TFCounter = new TrafficCounter();
$cron = $TFCounter->cron($url,$key,$magnification,$token);
$cron = json_decode($cron,true);
if (empty($cron)) {
	exit();
}
if ($cron['status'] = 'success')
{
    echo "\n Traffic data sync success.\n";
} else {
    echo "\n Traffic data sync failed.\n Reason:".$cron['message']."\n";
}
unset($TFCounter);
