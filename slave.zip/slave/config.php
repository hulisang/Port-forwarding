﻿<?php
$isGetConfig = false;
$nic = ['eth0'];
$sourceip = [''];
$url = 'https://zf.sushicloud.tech/modules/addons/PortForward/apicall.php';
$key = '123456789.';
$magnification = '1'; //流量倍率 默认为1
$node_bw_max = '5000'; //mbps
$token = 'vgvidcwniuidxeicofjx1606717861';
