﻿<?php
$isGetConfig = false;
$nic = ['eth0'];
$sourceip = [''];
$url = 'https://xxxx.xx/modules/addons/PortForward/apicall.php';
$key = 'wrt233';
$magnification = '1'; //流量倍率 默认为1
$node_bw_max = '5000'; //mbps
//$token
