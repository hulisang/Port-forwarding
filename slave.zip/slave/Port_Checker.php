<?php
namespace PortForward;
echo " PortForward Node v1.21 By Jiuling";
echo "\n Loading...\n";
require __DIR__ . "/init.php";
require __DIR__ . "/config.php";

use \PortForward\MethodDispatcher as MethodDispatcher;
use \PortForward\BandwidthLimter as BandwidthLimter;
use \PortForward\TrafficCounter as TrafficCounter;
use \PortForward\Base as Base;

if (PHP_SAPI != "cli") {
    exit('\n Run under cli!');
}
$base = new Base();
if (!isset($token))
{
    echo "\n Generating token...";
    $token = $base->rand_str();
    file_put_contents('config.php', '$token = \''.$token.'\';', FILE_APPEND | LOCK_EX );
    echo "\n Done";
}

$ip = trim($base->run("curl -s 'api.ip.sb/ip'"));
echo "\n Your IP: ".$ip;
if (!empty($isGetConfig)) {
	if($isGetConfig) {
		echo "\n Get config from master...\n\n";
		$data = [
    			'key' => $key,
			'token' => $token,
    			'action' => 'getconfig',
   			'0ba7yh8J' => 'aloIJ952xJ',
		];
		$result = json_decode($base->Post($url,$data),true);
		if ($result['status'] == 'success') {
			$magnification = $result['config']['magnification'];
			$node_bw_max = $result['config']['node_bw_max'];
		} else {
		echo "\n Failed to get config from master! \n";
		}
	}
}
echo "\n Geting Port Info...\n\n";
$data = [
    'key' => $key,
    'token' => $token,
    'action' => 'getport',
    'ip' => $ip,
    '0ba7yh8J' => 'aloIJ952xJ',
];

$port_data = $base->Post($url,$data);
if (empty($port_data)) {
	exit();
}
$port_data = json_decode($port_data,true);
if ($port_data['status'] == 'failed') {
    exit("\n Error!\n Message:".$port_data['message']);
}

$port_data = $port_data['data'];
$Dispatch = new MethodDispatcher();
$BWLimter = new BandwidthLimter();
$TFCounter = new TrafficCounter();
$counter = [
    'new' => 0,
    'exists' => 0,
    'del' => 0,
    'changed' => 0,
];
$file = __DIR__ . "/data/service.json";
$s = [];


foreach ($port_data as $port_curr)
{
    $port_curr['bandwidth'] = (int)$port_curr['bandwidth'] >= (int)$node_bw_max ? $node_bw_max : $port_curr['bandwidth'];
    $port_curr['sourceip'] = $sourceip;
    $port_curr['nic'] = $nic;
    if ($port_curr['status'] == 'pending' or $port_curr['status'] == 'created') // changed should delete first
    {
        $s[$port_curr['serviceid']]['port'][] = $port_curr['nodeport'];
        if (!$Dispatch->Dispatch($port_curr['method'], 'checkRepeat', $port_curr))
        {
            $Dispatch->Dispatch($port_curr['method'], 'create', $port_curr);
            $BWLimter->rule_create($port_curr);
            $TFCounter->create_traffic($port_curr);
            $counter['new']++;

        } else {
            $counter['exists']++;
        }
  } elseif ($port_curr['status'] == 'deleting' || $port_curr['status'] == 'suspend') {
        if ($Dispatch->Dispatch($port_curr['method'], 'checkRepeat', $port_curr)) {
            $Dispatch->Dispatch($port_curr['method'], 'delete', $port_curr);
            $BWLimter->rule_delete($port_curr);
            $TFCounter->delete_traffic($port_curr);
            $counter['del']++;
        }
  } elseif ($port_curr['status'] == 'changed') {
        $s[$port_curr['serviceid']]['port'][] = $port_curr['nodeport'];
        $Dispatch->Dispatch($port_curr['origin_method'], 'delete', $port_curr);
        $BWLimter->rule_delete($port_curr);
        $TFCounter->delete_traffic($port_curr);
        if (!$Dispatch->Dispatch($port_curr['method'], 'checkRepeat', $port_curr))
        {
            $Dispatch->Dispatch($port_curr['method'], 'create', $port_curr);
            $BWLimter->rule_create($port_curr);
            $TFCounter->create_traffic($port_curr);
            $counter['changed']++;
        }
  }
}

file_put_contents($file, json_encode($s));
echo "\n Port info saved.";
echo "\n All Done!";
echo "\n New:".$counter['new'];
echo "\n Exists:".$counter['exists'];
echo "\n Del:".$counter['del'];
echo "\n Changed:".$counter['changed']."\n";
