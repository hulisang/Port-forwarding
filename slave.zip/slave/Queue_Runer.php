<?php
namespace PortForward;
echo " PortForward Node v1.22 By Jiuling";
echo "\n Loading...\n";
require __DIR__ . "/init.php";
require __DIR__ . "/config.php";

use \PortForward\MethodDispatcher as MethodDispatcher;
use \PortForward\BandwidthLimter as BandwidthLimter;
use \PortForward\TrafficCounter as TrafficCounter;
use \PortForward\Base as Base;

if (PHP_SAPI != "cli") {
    exit('\n Run under cli!');
}
$base = new Base();
$Dispatch = new MethodDispatcher();
$BWLimter = new BandwidthLimter();
$TFCounter = new TrafficCounter();

echo "\n Geting Queue Task...\n\n";
$data = [
    'key' => $key,
    'token' => $token,
    'action' => 'getqueue',
    '0ba7yh8J' => 'aloIJ952xJ',
];

$queue_data = $base->Post($url,$data);
if (empty($queue_data)) {
	exit('\n Error! Can\'t get Queue Task!');
}
$queue_data = json_decode($queue_data,true);
if ($queue_data['status'] == 'failed') {
    exit("\n Error!\n Message:".$port_data['message']);
}

foreach ($queue_data['data'] as $queue_task)
{
	switch ($queue_task['action']) {
		case 'deleteport':
			if ($Dispatch->Dispatch('wstunnel', 'checkRepeat', $queue_task['data'])) {
				$Dispatch->Dispatch('wstunnel', 'delete', $queue_task['data']);
				$BWLimter->rule_delete($queue_task['data']);
				$TFCounter->delete_traffic($queue_task['data']);
			}
			break;
		default:
			echo "\n Don't support action: ".$queue_task['action'];
			break;
	}
}

echo "\n Done!"