<?php

use PortForward\Base;

class PortForward_wstunnel
{
    public $b;
    public function __construct()
    {
     	$this->b = new Base();
    }

    public function PortForward_wstunnel_create ($data) {
    	switch ($data['multi']) {
    		case 0:
    			$this->b->run("nohup gost -L rtcp://:" . $data['nodeport'] . "/" . $data['forwardip'] . ":" . $data['forwardport'] . " -L rudp://:" . $data['nodeport'] . "/" . $data['forwardip'] . ":" . $data['forwardport'] . " >> /usr/local/PortForward/slave/log/s" . $data['serviceid'] . ".log 2>&1 &");
    			break;
    		case 1:
				$this->b->run("nohup wstunnel -q -L 0.0.0.0:".$data['nodeport'].":".$data['dest_ip'].":".$data['dest_port']." ws://".$data['forwardip'].":".$data['forwardport']." >> /usr/local/PortForward/slave/log/s" . $data['serviceid'] . "ws.log 2>&1 &");
				$this->b->run("nohup wstunnel -q -u --udpTimeoutSec=80 -L 0.0.0.0:".$data['nodeport'].":".$data['dest_ip'].":".$data['dest_port']." ws://".$data['forwardip'].":".$data['forwardport']." >> /usr/local/PortForward/slave/log/s" . $data['serviceid'] . "ws.log 2>&1 &");
        		break;
			case 2:
        		$this->b->run("nohup wstunnel --server -q ws://0.0.0.0:".$data['nodeport']." -r ".$data['forwardip'].":".$data['forwardport']." >> /usr/local/PortForward/slave/log/s" . $data['serviceid'] . "ws.log 2>&1 &");
				break;
      }
      return true;
    }

    public function PortForward_wstunnel_delete ($data) {
        $pid = explode(',', $this->b->run("bash ".__DIR__."/socat.method.sh ".$data['nodeport']));
        foreach ($pid as $i) {
            $this->b->run('kill -9 '.$i);
        }
    }

    public function PortForward_wstunnel_checkRepeat ($data) {
        $res = $this->b->run("ps aux | grep ".$data['nodeport']." | sed '/grep/d' | awk '{print $2}'");
        if (!empty(trim($res))) {
            return true;
        }
		return false;
    }
}