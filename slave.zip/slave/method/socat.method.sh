#!/bin/sh

echo $(ps aux | grep $1 | sed '/grep/d' | awk '{print $2}' | sed ':label;N;s/\n/,/;b label')
