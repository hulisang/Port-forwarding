<?php

use PortForward\Base;

class PortForward_iptables
{
    public $rules;
    public $b;
    public function __construct()
    {
        $this->b = new Base();
        $this->rules = $this->b->run('iptables-save -t nat | grep \'TenVM Port Forward\'');
    }

    public function PortForward_iptables_create ($data)
    {
    	foreach($data['nic'] as $nic){
        	$this->b->run('iptables -t nat -A PREROUTING -i '.$nic.' -p tcp -m tcp --dport '.$data['nodeport'].' -j DNAT --to-destination '.$data['forwardip'].':'.$data['forwardport'].' -m comment --comment \'TenVM Port Forward\'');
        	$this->b->run('iptables -t nat -A PREROUTING -i '.$nic.' -p udp -m udp --dport '.$data['nodeport'].' -j DNAT --to-destination '.$data['forwardip'].':'.$data['forwardport'].' -m comment --comment \'TenVM Port Forward\'');
        }
	foreach($data['sourceip'] as $sip){
            $this->b->run('iptables -t nat -A POSTROUTING -d ' . $data['forwardip'] . '/32 -p udp -m udp --dport ' . $data['forwardport'] . ' -j SNAT --to-source ' . $sip . ' -m comment --comment \'TenVM Port Forward\'');
            $this->b->run('iptables -t nat -A POSTROUTING -d ' . $data['forwardip'] . '/32 -p tcp -m tcp --dport ' . $data['forwardport'] . ' -j SNAT --to-source ' . $sip . ' -m comment --comment \'TenVM Port Forward\'');
    	}
        return true;
    }

    public function PortForward_iptables_delete ($data)
    {
    	foreach($data['nic'] as $nic){
        	$this->b->run('iptables -t nat -D PREROUTING -i '.$nic.' -p tcp -m tcp --dport '.$data['nodeport'].' -j DNAT --to-destination '.$data['forwardip'].':'.$data['forwardport'].' -m comment --comment \'TenVM Port Forward\'');
        	$this->b->run('iptables -t nat -D PREROUTING -i '.$nic.' -p udp -m udp --dport '.$data['nodeport'].' -j DNAT --to-destination '.$data['forwardip'].':'.$data['forwardport'].' -m comment --comment \'TenVM Port Forward\'');
        }
	foreach($data['sourceip'] as $sip){
            $this->b->run('iptables -t nat -D POSTROUTING -d ' . $data['forwardip'] . '/32 -p udp -m udp --dport ' . $data['forwardport'] . ' -j SNAT --to-source ' . $sip . ' -m comment --comment \'TenVM Port Forward\'');
            $this->b->run('iptables -t nat -D POSTROUTING -d ' . $data['forwardip'] . '/32 -p tcp -m tcp --dport ' . $data['forwardport'] . ' -j SNAT --to-source ' . $sip . ' -m comment --comment \'TenVM Port Forward\'');
    	}
        return true;
    }

    public function PortForward_iptables_checkRepeat ($data)
    {
        $res = $this->b->run("iptables-save -t nat | grep \"".$data['nodeport']."\" | grep '\-j DNAT'");
        $res = str_replace(PHP_EOL, '', trim($res));
//	var_dump($res);
        if (!$res) {
            return true;
        }
        return false;
    }

}
