<?php

use PortForward\Base;

class PortForward_socat
{
    public $b;
    public function __construct()
    {
        $this->b = new Base();
    }

    public function PortForward_socat_create ($data) {
            $this->b->run("nohup socat TCP-LISTEN:" . $data['nodeport'] . ",reuseaddr,fork TCP:" . $data['forwardip'] . ":" . $data['forwardport'] . " >> /usr/local/PortForward/slave/log/s" . $data['serviceid'] . ".log 2>&1 &");
            $this->b->run("nohup socat -T 700 UDP-LISTEN:" . $data['nodeport'] . ",reuseaddr,fork UDP:" . $data['forwardip'] . ":" . $data['forwardport'] . " >> /usr/local/PortForward/slave/log/s" . $data['serviceid'] . ".log 2>&1 &");
            return true;
    }

    public function PortForward_socat_delete ($data) {
        $pid = explode(',', $this->b->run("bash ".__DIR__."/socat.method.sh ".$data['nodeport']));
        foreach ($pid as $i) {
            $this->b->run('kill -9 '.$i);
        }
    }

    public function PortForward_socat_checkRepeat ($data) {
        $res = $this->b->run("ps aux | grep TCP-LISTEN:".$data['nodeport']." | sed '/grep/d' | awk '{print $2}'");
        if (!empty(trim($res))) {
            return true;
        }
        return false;
    }
}
